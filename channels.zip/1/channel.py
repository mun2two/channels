import asyncio
from telethon import TelegramClient, errors
from telethon.tl.functions.channels import CreateChannelReq>

# Параметры API Telegram
api_id = 25362859
api_hash = '3274d35319cc610541fb434183adc67f'
session_name = 'phone'

# Инициализация клиента
client = TelegramClient(session_name, api_id, api_hash)

async def main():
    # Загрузка названий каналов из файла
    with open('channel_names.txt', 'r', encoding='utf-8') a>
        channel_names = f.read().splitlines()

    created_count = 0  # Счётчик созданных каналов

    for name in channel_names:
        if created_count >= 50:
            print("✅ Создано 50 каналов. Завершение.")
            break

        try:
            await client(CreateChannelRequest(
                title=name,
                about="",  # Без описания
                megagroup=False
            ))
            print(f"✅ Канал №{created_count + 1} '{name}' >
            created_count += 1
        except errors.FloodWaitError as e:
            print(f"⏳ FloodWait: Telegram требует подождат>
            await asyncio.sleep(e.seconds)
            await asyncio.exit()
            print("Попробуй завтра!")
        except Exception as e:
            print(f"❌ Ошибка при создании канала '{name}':>

        # Интервал 5 секунд между попытками
        await asyncio.sleep(5)

with client:
    client.loop.run_until_complete(main())


