import asyncio
from telethon import TelegramClient, errors
from telethon.tl.functions.channels import CreateChannelRequest

# Параметры API Telegram
api_id = 25362859
api_hash = '3274d35319cc610541fb434183adc67f'
session_name = 'phone'

# Инициализация клиента
client = TelegramClient(session_name, api_id, api_hash)

async def main():
    # Загрузка названий каналов из файла
    try:
        with open('channel_names.txt', 'r', encoding='utf-8') as f:
            channel_names = f.read().splitlines()
    except FileNotFoundError:
        print("❌ Файл 'channel_names.txt' не найден.")
        return

    created_count = 0  # Счётчик созданных каналов

    for name in channel_names:
        if created_count >= 50:
            print("✅ Создано 50 каналов. Завершение.")
            break

        try:
            result = await client(CreateChannelRequest(
                title=name,
                about="",
                megagroup=False
            ))
            created_count += 1
            print(f"✅ Канал №{created_count} '{name}' создан успешно.")
        except errors.FloodWaitError as e:
            print(f"⏳ FloodWait: нужно подождать {e.seconds} секунд.")
            await asyncio.sleep(e.seconds)
        except Exception as e:
            print(f"❌ Ошибка при создании канала '{name}': {e}")

        # Пауза между запросами
        await asyncio.sleep(5)

    print(f"🎉 Всего создано каналов: {created_count}")

# Запуск клиента
with client:
    client.loop.run_until_complete(main())
    